package com.margin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarginCallManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarginCallManagementSystemApplication.class, args);
	}

}
